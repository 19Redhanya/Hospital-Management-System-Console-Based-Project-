function check() {
    //----------name validiation------------
    var nam=f.name.value;
    if(nam==null || nam=="") {
        alert("Please fill the Name");
        return false;
    }
    //---------using regex------
    var rgx=/^[A-Za-z]+$/;
    if(!rgx.test(nam)) {
        alert("Name should not contain any special characters and numbers");
        document.getElementById("sname").style.visibility="visible";
        return false;
    }
    else {
        document.getElementById("sname").style.visibility="hidden";
    }
    //-----------Rollno validation-------
    var no=document.getElementById("rno").value;
    if(no=="")
    {
        alert("Please fill the Roll No");
        document.getElementById("snum").style.visibility="visible";
        return false;
    }
    //-----------password strength validation-----------
    var p=f.pword.value; 

    if(p.length < 6)
    {
        alert("Your password should contain atleast 6 characters");
        return false;
    }
    else if(p.lenght > 15)
    {
        alert("Your password should not contain more than 15 characters");
        return false;
    }
    //---------------check password-------------
    var cp=f.cword.value;
    if(p===cp)
    {
        // alert("Password and confirm password are same")
        return true;
    }
    else if(!(p===cp)){
        alert("The confirm password is wrong!!!..Enter the Correct password which you give in the password session");
        return false;
    }
    //----------------email validation----------------
    var x=document.f.email.value;    //    x -> email
    var atposition=x.indexOf("@");  
    var dotposition=x.lastIndexOf(".");  
    if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)    {  
        alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
        return false;  
    } 
    else if (x == null || x == "")
    {
        alert("Please fill the Email field");
        return false;
    }
}